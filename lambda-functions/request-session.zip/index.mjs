export const handler = async (event) => {
    const DEEPL_API_KEY = process.env.DEEPL_API_KEY;

    // Handle CORS preflight
    if (event.requestContext?.http?.method === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            }
        };
    }

    try {
        const body = JSON.parse(event.body || '{}');

        console.log('Requesting DeepL V2V session with config:', JSON.stringify(body, null, 2));

        const response = await fetch('https://api.deepl.com/v3/voice/realtime', {
            method: 'POST',
            headers: {
                'Authorization': `DeepL-Auth-Key ${DEEPL_API_KEY}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('DeepL API error:', response.status, errorText);
            throw new Error(`DeepL API error: ${response.status} - ${errorText}`);
        }

        const data = await response.json();
        console.log('Successfully created V2V session');

        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ error: error.message })
        };
    }
};
