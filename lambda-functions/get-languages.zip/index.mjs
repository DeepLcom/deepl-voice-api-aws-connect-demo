export const handler = async (event) => {
    // Handle CORS preflight
    if (event.requestContext?.http?.method === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            }
        };
    }

    try {
        // V3 Voice API doesn't have a languages endpoint
        // Return hardcoded list of supported languages
        const languages = [
            { language: 'en', name: 'English' },
            { language: 'de', name: 'German' },
            { language: 'es', name: 'Spanish' },
            { language: 'fr', name: 'French' },
            { language: 'it', name: 'Italian' },
            { language: 'pt', name: 'Portuguese' },
            { language: 'pl', name: 'Polish' },
            { language: 'nl', name: 'Dutch' },
            { language: 'ja', name: 'Japanese' },
            { language: 'zh', name: 'Chinese' },
            { language: 'ru', name: 'Russian' },
            { language: 'ko', name: 'Korean' }
        ];

        console.log('Returning hardcoded language list for v3 Voice API');

        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ languages })
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ error: error.message })
        };
    }
};
